


function adjust_stackInline_fieldset(){
    var set = "div.inline-related";
    var sFieldset = set + ">fieldset";
    var fs0 = $(sFieldset + ":eq(0)");
    var fs1 = $(sFieldset + ":eq(1)");
    if(fs0.length > 0 && fs1.length > 0 )
    {
        $(set).css({"position":"relative", "width":"100%"});
    
        fs1.css("top",fs0.position().top);
        fs0.css("width","50%");
        fs1.addClass("FloatRight");
        if(fs0.height()<fs1.height()){
            fs0.css("height",fs1.height());
        }

        var module_div_Description = $(sFieldset+":eq(0)>div.field-Description");
        var module_div_Description_textarea = $(sFieldset+":eq(0)>div.field-Description>div>textarea");    
        module_div_Description_textarea.css({'width':'60%','height':'50%'});        
    //    module_div_Description.css({'width':'90%','height':'40%', 'position': 'relative'});    
    }


}

function adjust_tabularInline_filedset(form_name){
    var s_module_div = "form#";
    s_module_div=s_module_div.concat(form_name);
    s_module_div=s_module_div.concat("_form>div");
    var module_div = $(s_module_div)
    module_div.css({"position":"relative", "width":"100%"});
    
    var module_div_fs0 = $(s_module_div+">fieldset:eq(0)");
    var module_div_fs1 = $(s_module_div+">fieldset:eq(1)");
    var module_div_fs2 = $(s_module_div+">fieldset:eq(2)"); 
    
    module_div_fs1.css("top",module_div_fs0.position().top);
    module_div_fs0.css("width","50%");
    module_div_fs0.css("min-width","450px");    
    module_div_fs1.addClass("FloatRight");
    module_div_fs1.css("min-width","450px");    
    if(module_div_fs2.length >0){
        module_div_fs0.css({"border-bottom":"none","border-right":"none"});
        module_div_fs1.css("border-bottom","none");    
        module_div_fs2.css("border-top","none");
    }
    
    var module_div_Description = $(s_module_div+">fieldset:eq(0)>div.field-Description");
    var module_div_Description_textarea = $(s_module_div+">fieldset:eq(0)>div.field-Description>div>textarea");    
    module_div_Description_textarea.css({'width':'60%','height':'50%'});        
//    module_div_Description.css({'width':'90%','height':'40%', 'position': 'relative'});    

    var max_height = module_div_fs1.height() > module_div_fs0.height() ? module_div_fs1.height() : module_div_fs0.height();
    module_div_fs0.css("height",max_height+5);
    module_div_fs1.css("height",max_height);

}

function adjust_link_formset(str_formset_table,array_td){
    // format the inline formset    

    var array_tr = array_td.concat();
    array_tr.shift();
    array_tr[0] = parseInt(array_td[0]) + parseInt(array_td[1]) + "%";  //td first item is original, tr merge firstly 2 column  
    
    $(str_formset_table).css({"width":"100%", "position":"relative"});

    var link_formset_tr = str_formset_table;

    link_formset_tr = link_formset_tr.concat(">thead>tr>th");
    $(link_formset_tr).css("text-align","center");
    var index = 0;
    var link_formset_tr_item;
    var link_formset_td_item;    
    for(index =0;index<array_tr.length;index++){
        link_formset_tr_item = $(link_formset_tr+":eq(" + index +")");
        link_formset_tr_item.css("width",array_tr[index]);
    }

    var link_formset_td = str_formset_table;
    link_formset_td = link_formset_td.concat(">tbody>tr>td");
    if($(link_formset_td).length > 0){
        for(index =0;index<array_td.length;index++){
            link_formset_td_item = $(link_formset_td+":eq(" + index +")");
            link_formset_td_item.css("width",array_td[index]);
        }
        $(link_formset_td).css({"position":"relative"});
        $(link_formset_td+" input").css("width","90%");        
        $(link_formset_td+" select").css("width", "100%");                
        $(link_formset_td+" textarea").css({"width":"95%", "height":"40px"}); 

        var link_formset_td_a = link_formset_td.concat(" a");
        
//        $(link_formset_td_a).css("margin", "10px");
//        $(link_formset_td_a).css("padding-top", "10px");
    }
}

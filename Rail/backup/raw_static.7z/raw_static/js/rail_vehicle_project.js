

/*

$(document).ready(function() {

    document.getElementById("id_area").innerHTML = "";
    document.getElementById("id_country").innerHTML = "";
    document.getElementById("id_region").innerHTML = "";
    document.getElementById("id_province").innerHTML = "";
    document.getElementById("id_city").innerHTML = "";
    
    adjust_stackInline_fieldset();
        
    adjust_tabularInline_filedset("rail_vehicle_project");

    var array_td = ["2%", "8%", "10%", "60%", "10%", "10%"]; //%
    adjust_link_formset("div#Rail_OEM_Project-group>div>fieldset>table", array_td);


    var s_vehicle_project_div = "form#rail_vehicle_project_form>div";
    var vehicle_project_div = $(s_vehicle_project_div)
    vehicle_project_div.css("position","relative");
    vehicle_project_div.css("width","100%");
    var vehicle_project_div_fs0 = $(s_vehicle_project_div+">fieldset:eq(0)");
    var vehicle_project_div_fs1 = $(s_vehicle_project_div+">fieldset:eq(1)");
    var vehicle_project_div_fs2 = $(s_vehicle_project_div+">fieldset:eq(2)");    
    vehicle_project_div_fs1.css("top",vehicle_project_div_fs0.position().top);


    vehicle_project_div_fs0.css("width","50%");
    vehicle_project_div_fs1.addClass("FloatRight");
	vehicle_project_div_fs0.css({"border-bottom":"none","border-right":"none"});
	vehicle_project_div_fs1.css("border-bottom","none");
	vehicle_project_div_fs2.css("border-top","none");

    var vehicle_project_div_Description = $(s_vehicle_project_div+">fieldset:eq(0)>div.field-Description");
    var vehicle_project_div_Description_textarea = $(s_vehicle_project_div+">fieldset:eq(0)>div.field-Description>div>textarea");    
    vehicle_project_div_Description.css({'width':'100%','height':'40%'});    
    vehicle_project_div_Description_textarea.css({'width':'60%','height':'100%'});    	
    
});

*/


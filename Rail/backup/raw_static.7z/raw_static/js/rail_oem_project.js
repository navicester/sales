
$(document).ready(function() {
/*
    $("#tabs").tabs();
    $("#tabs-rail-bidding").tabs();    
*/

/*
    var s_oem_project_div = "form#rail_oem_project_form>div";
    var oem_project_div = $(s_oem_project_div)
    oem_project_div.css("position","relative");
    oem_project_div.css("width","100%");
    var oem_project_div_fs0 = $(s_oem_project_div+">fieldset:eq(0)");
    var oem_project_div_fs1 = $(s_oem_project_div+">fieldset:eq(1)");
    var oem_project_div_fs2 = $(s_oem_project_div+">fieldset:eq(2)");    
    oem_project_div_fs1.css("top",oem_project_div_fs0.position().top);


    oem_project_div_fs0.css("width","50%");
    oem_project_div_fs1.addClass("FloatRight");
    
    oem_project_div_fs0.css({"border-bottom":"none","border-right":"none"});
    oem_project_div_fs1.css("border-bottom","none");    
    oem_project_div_fs2.css("border-top","none");
    
    var oem_project_div_Description = $(s_oem_project_div+">fieldset:eq(0)>div.field-Description");
    var oem_project_div_Description_textarea = $(s_oem_project_div+">fieldset:eq(0)>div.field-Description>div>textarea");    
    oem_project_div_Description.css({'width':'100%','height':'40%'});    
    oem_project_div_Description_textarea.css({'width':'60%','height':'100%'});        
*/

    adjust_tabularInline_filedset("rail_oem_project");

    var array_td = ["2%", "28%", "30%", "35%"]; //%
    adjust_link_formset("div#rail_tracking_set-group>div>fieldset>table", array_td);

    var array_td = ["2%", "28%", "30%", "35%"]; //%
    adjust_link_formset("div#rail_project_in_charge_set-group>div>fieldset>table", array_td);

    var array_td = ["2%", "10%", "50%", "10%", "18%"]; //%
    adjust_link_formset("div#rail_customer_bidding_set-group>div>fieldset>table", array_td);

    var array_td = ["2%", "10%", "10%", "50%", "12%", "12%"]; //%
    adjust_link_formset("div#rail_competitor_bidding_set-group>div>fieldset>table", array_td);

    var array_td = ["2%", "8%", "50%", "12%", "12%", "12%"]; //%
    adjust_link_formset("div#Rail_Bidding-group>div>fieldset>table", array_td);  //name rule is different

});

function BtnshowAddAnotherPopup(triggeringLink) {
    var name = triggeringLink.id.replace(/^add_/, '');
    name = id_to_windowname(name);
    href = "/index/Rail/vehicle_project/add/";
    if (href.indexOf('?') == -1) {
        href += '?_popup=1';
    } else {
        href  += '&_popup=1';
    }
    var win = window.open(href, name, 'height=500,width=800,resizable=yes,scrollbars=yes');
    win.focus();
    return false;
}




$(document).ready(function() {
    adjust_tabularInline_filedset("rail_contract");

/*
    var s_oem_project_div = "form#rail_contract_form>div";
    var oem_project_div = $(s_oem_project_div)
    oem_project_div.css("position","relative");
    oem_project_div.css("width","100%");
    var oem_project_div_fs0 = $(s_oem_project_div+">fieldset:eq(0)");
    var oem_project_div_fs1 = $(s_oem_project_div+">fieldset:eq(1)");
    var oem_project_div_fs2 = $(s_oem_project_div+">fieldset:eq(2)");    
    oem_project_div_fs1.css("top",oem_project_div_fs0.position().top);


    oem_project_div_fs0.css("width","50%");
    oem_project_div_fs1.addClass("FloatRight");
	oem_project_div_fs0.css({"border-bottom":"none","border-right":"none"});
	oem_project_div_fs1.css("border-bottom","none");    
	oem_project_div_fs2.css("border-top","none");

    var oem_project_div_Description = $(s_oem_project_div+">fieldset:eq(0)>div.field-Description");
    var oem_project_div_Description_textarea = $(s_oem_project_div+">fieldset:eq(0)>div.field-Description>div>textarea");    
    oem_project_div_Description.css({'width':'100%','height':'40%'});    
    oem_project_div_Description_textarea.css({'width':'60%','height':'100%'});    
*/    
});


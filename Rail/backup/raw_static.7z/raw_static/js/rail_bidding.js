$(document).ready(function() {

    adjust_tabularInline_filedset("rail_bidding");

    // original name description quantity price product_type product_group configuration
    var array_td = ["2%", "8%", "25%", "5%", "5%", "10%", "10%", "10%", "10%"]; //%
    adjust_link_formset("div#rail_package_line_set-group>div>fieldset>table", array_td);

    var array_td = ["2%", "8%", "10%", "70%", "10%"]; //%
    adjust_link_formset("div#Rail_Package-group>div>fieldset>table", array_td);


/*
    var s_rail_bidding_div = "form#rail_bidding_form>div";
    var rail_bidding_div = $(s_rail_bidding_div)
    rail_bidding_div.css("position","relative");
    rail_bidding_div.css("width","100%");
    var rail_bidding_div_fs0 = $(s_rail_bidding_div+">fieldset:eq(0)");
    var rail_bidding_div_fs1 = $(s_rail_bidding_div+">fieldset:eq(1)");
    rail_bidding_div_fs1.css("top",rail_bidding_div_fs0.position().top);


    rail_bidding_div_fs0.css("width","50%");
    rail_bidding_div_fs1.addClass("FloatRight");

    var max_height = rail_bidding_div_fs1.height() > rail_bidding_div_fs0.height() ? rail_bidding_div_fs1.height() : rail_bidding_div_fs0.height();
    rail_bidding_div_fs0.css("height",max_height+5);
    rail_bidding_div_fs1.css("height",max_height);
    
    var rail_bidding_div_fs0_reason = $(s_rail_bidding_div+">fieldset:eq(0)>div.field-Reason");
    var rail_bidding_div_fs0_reason_textarea = $(s_rail_bidding_div+">fieldset:eq(0)>div.field-Reason>div>textarea");
    rail_bidding_div_fs0_reason.css({'width':'100%'});
    rail_bidding_div_fs0_reason_textarea.css({'width':'60%','height':'100%'});
*/    
    
/*
    $("div#package_line_set-group>div>fieldset>table").css("width","100%");
    $("div#package_line_set-group>div>fieldset>table").css("position","relative");
    
    var package_line_tr = "div#package_line_set-group>div>fieldset>table>thead>tr>th";
    $(package_line_tr).css("text-align","center");
    package_line_tr_name = $(package_line_tr+":eq(0)");
    package_line_tr_description = $(package_line_tr+":eq(1)");
    package_line_tr_quantity = $(package_line_tr+":eq(2)");
    package_line_tr_price = $(package_line_tr+":eq(3)");
    package_line_tr_productType = $(package_line_tr+":eq(4)");
    package_line_tr_productGroup = $(package_line_tr+":eq(5)");
    package_line_tr_configuration = $(package_line_tr+":eq(6)");
    
    package_line_tr_name.css("width","10%");
    package_line_tr_description.css("width","30%");
    package_line_tr_quantity.css("width","10%");
    package_line_tr_price.css("width","10%");
    package_line_tr_productType.css("width","10%");
    package_line_tr_productGroup.css("width","10%");
    package_line_tr_configuration.css("width","10%");



    var package_line_td = "div#package_line_set-group>div>fieldset>table>tbody>tr>td";
    if($(package_line_td).length > 0){
        
        package_line_td_original = $(package_line_td+":eq(0)");
        package_line_td_name = $(package_line_td+":eq(1)");    
        package_line_td_description = $(package_line_td+":eq(2)");
        package_line_td_quantity = $(package_line_td+":eq(3)");
        package_line_td_price = $(package_line_td+":eq(4)");
        package_line_td_productType = $(package_line_td+":eq(5)");
        package_line_td_productGroup = $(package_line_td+":eq(6)");
        package_line_td_product = $(package_line_td+":eq(7)");        
        package_line_td_configuration = $(package_line_td+":eq(8)");
            
        package_line_td_original.css('width','5%');
        package_line_td_name.css("width","5%");    
        package_line_td_description.css('width','25%');
        package_line_td_quantity.css("width","5%");
        package_line_td_price.css("width","5%");
        package_line_td_productType.css("width","10%");
        package_line_td_productGroup.css("width","10%");
        package_line_td_product.css("width","10%");        
        package_line_td_configuration.css("width","10%");

        $(package_line_td+">input").css("width","95%");        
        $(package_line_td+">textarea").css("width","95%");        
        $(package_line_td+">textarea").css("height","40px");        
    }
*/    

});

function BtnshowAddAnotherPopup(triggeringLink) {
    var name = triggeringLink.id.replace(/^add_/, '');
    name = name.replace(/_id/, '');
    name = name.replace(/id_/, '');
    name = name + '_list';
    href = "/index/Rail/rail_package/add/";
    if (href.indexOf('?') == -1) {
        href += '?_popup=1';
    } else {
        href  += '&_popup=1';
    }
    var win = window.open(href, name, 'height=500,width=1000,resizable=yes,scrollbars=yes');
    win.focus();
    return false;
}

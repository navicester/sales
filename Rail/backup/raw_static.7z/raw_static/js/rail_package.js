$(document).ready(function() {
    /*
    var s_rpkg_div = "form#rail_package_form>div";
    var rpkg_div = $(s_rpkg_div)
    rpkg_div.css("position","relative");
    rpkg_div.css("width","100%");
    var rpkg_div_fs0 = $(s_rpkg_div+">fieldset:eq(0)");
    var rpkg_div_fs1 = $(s_rpkg_div+">fieldset:eq(1)");
    rpkg_div_fs1.css("top",rpkg_div_fs0.position().top);

    rpkg_div_fs0.css("width","50%");
    rpkg_div_fs1.addClass("FloatRight");
    var rpkg_div_fs0_description = $(s_rpkg_div+">fieldset:eq(0)>div.field-Description");
    rpkg_div_fs0_description.css("width","200%");
    var max_height = rpkg_div_fs1.height() > rpkg_div_fs0.height() ? rpkg_div_fs1.height() : rpkg_div_fs0.height();
    rpkg_div_fs0.css("height",max_height+5);
    rpkg_div_fs1.css("height",max_height);
    */

    adjust_tabularInline_filedset("rail_package");

/*    // format the inline formset    
    $("div#rail_package_line_set-group>div>fieldset>table").css("width","100%");
    $("div#rail_package_line_set-group>div>fieldset>table").css("position","relative");

    var package_line_tr = "div#rail_package_line_set-group>div>fieldset>table>thead>tr>th";
    $(package_line_tr).css("text-align","center");
    var index = 0;
    package_line_tr_description = $(package_line_tr+":eq(" + index++ +")");
    package_line_tr_quantity = $(package_line_tr+":eq(" + index++ +")");
    package_line_tr_price = $(package_line_tr+":eq(" + index++ +")");
    package_line_tr_productType = $(package_line_tr+":eq(" + index++ +")");
    package_line_tr_productGroup = $(package_line_tr+":eq(" + index++ +")");
    package_line_tr_configuration = $(package_line_tr+":eq(" + index++ +")");
    
    package_line_tr_description.css("width","30%");
    package_line_tr_quantity.css("width","10%");
    package_line_tr_price.css("width","10%");
    package_line_tr_productType.css("width","10%");
    package_line_tr_productGroup.css("width","10%");
    package_line_tr_configuration.css("width","10%");



    var package_line_td = "div#rail_package_line_set-group>div>fieldset>table>tbody>tr>td";
    if($(package_line_td).length > 0){
//        $("div#package_line_set-group>div>fieldset>table>tbody>tr").css("width","100%");

        var idx = 0;
        package_line_td_original = $(package_line_td+":eq(" + idx++ + ")");
        package_line_td_description = $(package_line_td+":eq(" + idx++ + ")");
        package_line_td_quantity = $(package_line_td+":eq(" + idx++ + ")");
        package_line_td_price = $(package_line_td+":eq(" + idx++ + ")");
        package_line_td_productType = $(package_line_td+":eq(" + idx++ + ")");
        package_line_td_productGroup = $(package_line_td+":eq(" + idx++ + ")");
        package_line_td_product = $(package_line_td+":eq(" + idx++ + ")");
        package_line_td_configuration = $(package_line_td+":eq(" + idx++ + ")");
            
        package_line_td_original.css('width','2%');
        package_line_td_description.css('width','33%');
        package_line_td_quantity.css("width","5%");
        package_line_td_price.css("width","5%");
        package_line_td_productType.css("width","10%");
        package_line_td_productGroup.css("width","10%");
        package_line_td_product.css("width","10%");        
        package_line_td_configuration.css("width","10%");

        $(package_line_td+" input").css("width","95%");        
        $(package_line_td+" textarea").css("width","95%");        
        $(package_line_td+" textarea").css("height","40px"); 
    }
*/
    var array_td = ["2%", "33%", "30%", "10%", "10%", "10%", "10%", "10%"];
    adjust_link_formset("div#rail_package_line_set-group>div>fieldset>table", array_td);    
});

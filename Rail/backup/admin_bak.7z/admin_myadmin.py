from django.contrib.admin.options import *
from django.contrib import admin  
from Rail import models, admin_linkform, admin_linkmodel
from Rail.models import *
from Rail.forms import *
from Rail.admin_linkform import *
from Rail.admin_linkmodel import *



